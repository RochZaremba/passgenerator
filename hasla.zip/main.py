import random
filename = "hasla.txt"

czy_powturzyc = True
wszystko = []

znaki_specjalne = []


def czy(w):
    w.split()
#cyfry
    if w.find("c") >= 0:
        for i in range(48, 58):
            wszystko.append(i)

# znaki specjalne
    if w.find("z") >= 0:
        for i in range(33, 48):
            wszystko.append(i)
        for i in range(58, 65):
            wszystko.append(i)
        for i in range(91, 97):
            wszystko.append(i)
        for i in range(123, 127):
            wszystko.append(i)

# wielkie litery
    if w.find("w") >= 0:
        for i in range(65, 58):
            wszystko.append(i)
    return 0
def print_hi(name):
    # pobieranie danych od urzytkownika
    print("")
    print("Podaj wymagania do stworzenia hasła, odziel je spacją.\n")
    wymagania = (input(" M - małe litery\n W - wielkie litery\n Z - znaki specjalne \n C - cyfry\n")).lower()
    while len(wymagania) < 1 :
        wymagania = (input(" M - małe litery\n W - wielkie litery\n Z - znaki specjalne \n C - cyfry\n")).lower()

    dlugosc = input("podaj długość twojego hasła\n")
    while len(dlugosc) < 1 or int(dlugosc) < 1:
        dlugosc = input("podaj długość twojego hasła\n")
    w = wymagania
    w.split()
    # cyfry
    if w.find("c") >= 0:
        for i in range(48, 58):
            wszystko.append(i)
    # małe litery
    if w.find("m") >= 0:
        for i in range(48, 58):
            wszystko.append(i)

    # znaki specjalne
    if w.find("z") >= 0:
        for i in range(33, 48):
            wszystko.append(i)
        for i in range(58, 65):
            wszystko.append(i)
        for i in range(91, 97):
            wszystko.append(i)
        for i in range(123, 127):
            wszystko.append(i)

    # wielkie litery

    if w.find("w") >= 0:
        for i in range(65, 58):
            wszystko.append(i)

    haslo = ""
    for i in range(int(dlugosc)):
        haslo = haslo + chr(wszystko[random.randrange(len(wszystko)-1)])
    print(haslo)
    with open(filename,"w") as file:
        file.write(haslo+'\n')

if __name__ == '__main__':
    while czy_powturzyc:
        if 't' == (input("Czy wyświetlić wscześniej wygenerowane hasła ?(T/N)\n")).lower():
            print("Wcześniej wygenerowane hasła : \n")
            with open(filename,'r')as file:
                for line in file:
                    print(line.strip())
        print_hi('PyCharm')
        if "n" == (input("czy wynenerować kolejne hasło ?(T/N)\n")).lower():
            czy_powturzyc = False